CRESTIQ KitchenSync demo
Open index.html in Chrome or Edge. No server or installation required.
Demo: Load sample combo > Place combined order > Kitchen Control > Generate rush-hour demo > Station Displays > Analytics > Voice/Text Intake.
This is a front-end functional prototype with an in-memory scheduler and sample prices/timings, not a production backend. Data resets on refresh. Voice capture requires browser support/permissions.
